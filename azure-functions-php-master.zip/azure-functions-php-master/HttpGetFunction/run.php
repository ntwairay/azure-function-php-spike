<?php

//retrieve original GET string
$getReqString = getenv('REQ_QUERY');

//remove the ? for the parse_str function $getReqString = substr($getReqString,1,strlen($getReqString));

//convert the GET string to an array
$parsedRequest = array(); parse_str($getReqString,$parsedRequest);

//show contents of the new array
print_r($parsedRequest);

//show the value of a GET variable
echo $parsedRequest["code"];

?>
